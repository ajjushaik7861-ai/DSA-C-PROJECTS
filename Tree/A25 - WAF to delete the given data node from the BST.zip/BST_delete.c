#include "tree.h"

extern int status;
/* Function to delete the node  */
Tree_t * delete_BST(Tree_t * root, int data)
{
    status=0;
    if(root==NULL)
    {
        //status=NOELEMENT;
        return NULL;
    }
    int flag=-1;
    Tree_t *temp=root;
    Tree_t *prev=NULL;
    
    //search node
    while(temp!=NULL && temp->data!=data)
    {
        prev=temp;
        if(data<temp->data)
        {
            flag=0;
            temp=temp->left;
        }
        else
        {
            flag=1;
            temp=temp->right;
        }
    }
    //data not found
    if(temp==NULL)
    {
        status=NOELEMENT;
        return root;//data not found
    }
    
    //two children case
    if(temp->left!=NULL && temp->right!=NULL)
    {
        Tree_t *succ=temp->right;
        Tree_t *succ_prev=temp;
        
        while(succ->left!=NULL)
        {
            succ_prev=succ;
            succ=succ->left;
        }
    
        temp->data=succ->data;
        temp=succ;
        prev=succ_prev;
    
        if(prev->left==temp)
        {
            flag=0;
        }
        else
        {
            flag=1;
        }
    }
    //zero or one child
    Tree_t *child;
    if(temp->left!=NULL)
    {
        child=temp->left;
    }
    else
    {
        child=temp->right;
    }
    //root delete
    if(prev==NULL && temp==root)
    {
        free(temp);
        status=1;
        return child;
    }
    //connect parent
    if(flag==0)
    {
        prev->left=child;
    }
    else
    {
        prev->right=child;
    }
    free(temp);
    status=1;
    return root;
}