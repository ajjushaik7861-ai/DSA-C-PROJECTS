#include "tree.h"

int findmin(Tree_t * root)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    
    if(root->left!=NULL)
    {
        root=root->left;
    }
    return root->data;
}
