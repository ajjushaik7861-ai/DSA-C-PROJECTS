#include "tree.h"

/* Function to print the data in in order printing */
int inorder(Tree_t *root)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    
    inorder(root->left);//visit left
    printf("%d ",root->data);//visit parent
    inorder(root->right);//visit right
}