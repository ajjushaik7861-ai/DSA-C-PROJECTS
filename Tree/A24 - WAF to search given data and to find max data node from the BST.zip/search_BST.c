#include "tree.h"

/* Iteratively */
int search_BST(Tree_t *root, int data)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    
    Tree_t *temp=root;
    
    while(temp!=NULL)
    {
        if(data==temp->data)
        {
            return SUCCESS;//found data
        }
        else if(data<temp->data)
        {
            temp=temp->left;//search left side
        }
        else
        {
            temp=temp->right;//search right side
        }
    }
    return NOELEMENT;//not found
}