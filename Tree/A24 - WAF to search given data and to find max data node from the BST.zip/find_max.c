#include "tree.h"

int findmax(Tree_t * root)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    
    Tree_t *temp=root;
    while(root->right!=NULL)
    {
        root=root->right;
    }
    return root->data;
}
