#include "tree.h"

/* Function to insert the data's in BST */
int insert_into_BST(Tree_t **root, int data)
{
    Tree_t *new=malloc(sizeof(Tree_t));//create new node
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->left=NULL;
    new->right=NULL;
    
    //if list is empty
    if(*root==NULL)
    {
        *root=new;
        return SUCCESS;
    }
    
    Tree_t *temp=*root;
    Tree_t *parent=NULL;
    
    while(temp!=NULL)
    {
        parent=temp;
        if(data<temp->data)
        {
            temp=temp->left;
        }
        else if(data>temp->data)
        {
            temp=temp->right;
        }
        else
        {
            //duplicate value not allowed
            free(new);
            return FAILURE;
        }
    }
    if(data<parent->data)
    parent->left=new;
    else
    parent->right=new;
    return SUCCESS;
}
    
    