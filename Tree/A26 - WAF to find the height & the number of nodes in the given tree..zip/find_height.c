#include "tree.h"

int find_height(Tree_t *root)
{
    if(root==NULL)
    {
        return 0;
    }
    
    int left_height=find_height(root->left);
    int right_height=find_height(root->right);
    
    if(left_height>right_height)
    {
        return 1+left_height;
    }
    else
    {
        return 1+right_height;
    }
}
