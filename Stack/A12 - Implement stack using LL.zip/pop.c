#include "stack.h"

int Pop(Stack_t **top)
{
    Stack_t *temp;
    
    if(*top==NULL)/* Check for empty stack */

    {
        return FAILURE;
    }
    
    temp=*top;//store current top
    *top=temp->link;//move top to next node
    free(temp);//free old top
    return SUCCESS;
}