#include "main.h"

data_t selection(data_t *arr, data_t size )
{
    int i,j,idx,min;
    for(i=0;i<size;i++)
    {
        min=arr[i];
        idx=i;
        for(j=i;j<size;j++)
        {
            if(arr[j]<min)
            {
                
                min=arr[j];
                idx=j;
            }
        }
        if(idx!=i)
        {
            int temp=arr[i];
            arr[i]=arr[idx];
            arr[idx]=temp;
        }
    }
}
