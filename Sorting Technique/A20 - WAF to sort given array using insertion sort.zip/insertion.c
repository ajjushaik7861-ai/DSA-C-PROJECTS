#include "main.h"

data_t insertion(data_t *arr, data_t size)
{
    int i,j,key;
    for(i=1;i<size;i++)
    {
        key=arr[i];
        for(j=i-1;j>=0;j--)
        {
            if(key<arr[j])
            {
                arr[j+1]=arr[j];
            }
            else
            {
                break;
            }
        }
        arr[j+1]=key;
    }
}
