#include "main.h"

/* Function to sort the array in quick sort method */
int quick_sort( int *arr, int first, int last )
{
    int index;
    if(first<last)
    {
        index=partition(arr,first,last);//partition index
        
        quick_sort(arr,first,index-1);//sort left sub array
        
        quick_sort(arr,index+1,last);//sort right sub array
    }
    return 1;
}
