#include "main.h"

/* Function to partition the array */
int partition(int *arr, int first, int last)
{
    int pivot=arr[first];
    int i=first+1;
    int j=last;
    int temp;
    
    while(i<=j)
    {
        while(i<=last && arr[i]<=pivot)//move i forward while element <=pivot
        {
            i++;
        }
        
        while(arr[j]>pivot)//move j backward while element >pivot
        {
            j--;
        }
        //swap if needed
        if(i<j)
        {
            temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }
    //place pivot in correct postion
    temp=arr[first];
    arr[first]=arr[j];
    arr[j]=temp;
    return j;//pivot index
}
