#include"hash.h"

int search_HT(hash_t *arr, int data, int size)
{
    int index=data%size;
    
    hash_t *temp=&arr[index];
    
    if(temp->value==-1)
    {
        printf("INFO : Data not found\n");
        return LIST_EMPTY;
    }
    
    while(temp!=NULL)
    {
        if(temp->value==data)
        {
            printf("INFO : %d is found at the index %d\n", data, index);
            return SUCCESS;
        }
        temp=temp->link;
    }
    printf("INFO : Data not found\n");
    return DATA_NOT_FOUND;
}