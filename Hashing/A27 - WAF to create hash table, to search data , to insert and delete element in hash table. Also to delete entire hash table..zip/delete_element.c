#include"hash.h"

int delete_element(hash_t *arr, int data, int size)
{
    int index=data%size;
    
    hash_t *curr=&arr[index];
    hash_t *prev=NULL;
    
    if(curr->link==NULL && curr->value!=data)//if list is empty
    {
        return LIST_EMPTY;
    }
    
    if(curr->value==data)
    {
        if(curr->link!=NULL)
        {
            hash_t *temp=curr->link;
            
            curr->value=temp->value;
            curr->link=temp->link;
            
            free(temp);
        }
        else
        {
            curr->value=-1;//make as emptyy
        }
        return SUCCESS;
    }
    prev=curr;
    curr=curr->link;
    
    //traversing 
    while(curr!=NULL)
    {
        if(curr->value==data)
        {
            prev->link=curr->link;
            free(curr);
            return SUCCESS;
        }
        
        prev=curr;
        curr=curr->link;
    }
    
    return DATA_NOT_FOUND;
}