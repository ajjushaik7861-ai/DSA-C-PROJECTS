#include "sll.h"

int sl_sort(Slist **head)
{
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    if((*head)->link==NULL)
    {
        return SUCCESS;
    }
    
    Slist *temp=*head;
    int count=0;
    
    while(temp!=NULL)
    {
        count++;
        temp=temp->link;
    }
    
    Slist *temp1,*temp2,*prev;
    
    for(int i=0;i<count-1;i++)
    {
        temp1=*head;
        temp2=temp1->link;
        prev=NULL;
        for(int j=0;j<count-i-1;j++)
        {
            if(temp1->data>temp2->data)
            {
                temp1->link=temp2->link;
                temp2->link=temp1;
                if(prev==NULL)
                {
                    *head=temp2;
                }
                else
                {
                    prev->link=temp2;
                }
                prev=temp2;
                temp2=temp1->link;
            }
            else
            {
                prev=temp1;
                temp1=temp2;
                temp2=temp2->link;
            }
        }
    }
    return SUCCESS;
}