#include "sll.h"

//remove duplicate data's from list
int remove_duplicates( Slist **head )
{
    if(*head==NULL)
    {
        return FAILURE;
    }
    
    Slist *temp1;
    Slist *temp2;
    Slist *prev;
    
    temp1=*head;
    while(temp1!=NULL)
    {
        prev=temp1;
        temp2=temp1->link;
        while(temp2!=NULL)
        {
            if(temp1->data==temp2->data)
            {
                prev->link=temp2->link;
                free(temp2);
                temp2=prev->link;
            }
            else
            {
                prev=temp2;
                temp2=temp2->link;
            }
        }
        temp1=temp1->link;
    }
    return SUCCESS;
}