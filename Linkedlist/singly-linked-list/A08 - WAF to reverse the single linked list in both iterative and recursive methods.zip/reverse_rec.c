#include "sll.h"

int reverse_recursion(Slist ** head)
{
    static Slist *prev=NULL;
    Slist *current=*head;
    Slist *next=NULL;
    
    if(current==NULL)
    if(prev==NULL && *head==NULL)
    {
        return LIST_EMPTY;
    }
    
    if(current==NULL)
    {
        *head=prev;
        prev=NULL;
        return SUCCESS;
    }
    
    next=current->link;
    current->link=prev;
    prev=current;
    *head=next;
    return reverse_recursion(head);
}