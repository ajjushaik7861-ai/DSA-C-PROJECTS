#include "sll.h"

/* Function to reverse the given single linked list */
int reverse_iter(Slist **head) 
{ 
    Slist *current=*head;
    Slist *prev=NULL;
    Slist *next=NULL;
    
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    while(current!=NULL)
    {
        next=current->link;
        current->link=prev;
        prev=current;
        current=next;
    }
    *head=prev;
    return SUCCESS;
} 