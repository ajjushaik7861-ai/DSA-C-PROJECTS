#include "sll.h"

int insert_at_first(Slist **head, data_t data)
{
    Slist *new=malloc(sizeof(Slist));
    if(new==NULL)
    {
        printf("ERROR : MEMORY NOT ALLOCATED\n");
        return FAILURE;
    }
    if(*head==NULL)
    {
        printf("List is empty\n");
        new->data=data;
        new->link=NULL;
        *head=new;
    }
    else
    {
        new->data=data;
        new->link=*head;
        *head=new;
    }
}