#include "sll.h"

int find_node(Slist *head, data_t data)
{
    int pos=1;
    if(head==NULL)
    {
        return FAILURE;
    }
    
    while(head!=NULL)
    {
        if(head->data==data)
        {
            return pos;
        }
        head=head->link;
        pos++;
    }
    return -1;
}
