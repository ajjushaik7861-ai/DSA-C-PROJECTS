#include "sll.h"

int sl_delete_last(Slist **head)
{
    if(*head==NULL)//list is empty
    {
        return FAILURE;
    }
    if((*head)->link==NULL)//only one node in the list 
    {
        free(*head);
        *head=NULL;
        return SUCCESS;
    }
    //if more than one node
    Slist *prev=NULL;
    Slist *temp=*head;
    while(temp->link!=NULL)
    {
        prev=temp;
        temp=temp->link;
    }
    free(temp);
    prev->link=NULL;
    return SUCCESS;
}
    