#include "sll.h"

int insert_at_last(Slist **head, data_t data)
{
    Slist *new=malloc(sizeof(Slist));//create new node 
    if(new==NULL)
    return FAILURE;
    new->data=data;
    new->link=NULL;
    
    if(*head==NULL)//check node is points to null or not 
    {
        *head=new;
        return SUCCESS;
    }
    else
    {
        Slist *temp=*head;//take one temp var
        
        while(temp->link!=NULL)//run the loop untill null occurs
        {
            temp=temp->link;
        }
        temp->link=new;
        return SUCCESS;
    }
}