#include "sll.h"

int sl_delete_list(Slist **head)
{
    if(*head==NULL)
    return FAILURE;
    printf("ERROR : List is empty\n");
    
    Slist *temp;
    while(*head!=NULL)
    {
        temp=*head;
        *head=temp->link;
        free(temp);
    }
    return SUCCESS;
}