#include "sll.h"

int sl_insert_nth(Slist **head, data_t data, int pos)
{
    Slist *new = NULL, *temp = *head;
    int count = 1;
    //EMPTY LIST CASE
    if (*head == NULL)
    {
        if (pos == 1)   // VALID
        {
            new = malloc(sizeof(Slist));
            if (new == NULL)
                return FAILURE;

            new->data = data;
            new->link = NULL;
            *head = new;
            return SUCCESS;
        }
        else// INVALID
        {
            return LIST_EMPTY; //T LIST_EMPTY
        }
    }
    // Insert at first position (non-empty)
    if (pos == 1)
    {
        new = malloc(sizeof(Slist));
        if (new == NULL)
            return FAILURE;

        new->data = data;
        new->link = *head;
        *head = new;
        return SUCCESS;
    }
    // Traverse to position-1
    while (temp != NULL && count < pos - 1)
    {
        temp = temp->link;
        count++;
    }
    // Position not found
    if (temp == NULL)
    {
        return POSITION_NOT_FOUND;
    }
    // Insert normally
    new = malloc(sizeof(Slist));
    if (new == NULL)
        return FAILURE;

    new->data = data;
    new->link = temp->link;
    temp->link = new;

    return SUCCESS;
}
