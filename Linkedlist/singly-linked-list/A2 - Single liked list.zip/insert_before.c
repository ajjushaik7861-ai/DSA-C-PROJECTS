#include "sll.h"

int sl_insert_before(Slist **head, data_t g_data, data_t ndata)
{
    Slist *temp=*head;
    Slist *prev=NULL;
    Slist *new=NULL;
    
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    while(temp!=NULL)//Traverse the list 
    {
        if(temp->data==g_data)//CHECK DATA EQUAL ARE NOT
        {
            new=malloc(sizeof(Slist));
            if(new==NULL)
            {
                return FAILURE;
            }
            new->data=ndata;
            new->link=temp;
            
           //case 2: inserting befor head
           if(prev==NULL)
           {
               *head=new;
           }
           else
           {
               prev->link=new;
           }
           return SUCCESS;
        }
        prev=temp;
        temp=temp->link;
    }
    return DATA_NOT_FOUND;
}