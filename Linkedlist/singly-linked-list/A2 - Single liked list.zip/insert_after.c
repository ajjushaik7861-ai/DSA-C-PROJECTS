#include "sll.h"

int sl_insert_after(Slist **head, data_t g_data, data_t ndata)
{
    Slist *new=NULL;
    Slist *temp=*head;
    
    //case1: list is empty
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    //traverse the list
    while(temp!=NULL)
    {
        if(temp->data==g_data)
        {
            new=malloc(sizeof(Slist));
            if(new==NULL)
            {
                return FAILURE;
            }
            new->data=ndata;
            new->link=temp->link;
            temp->link=new;
            
            return SUCCESS;
        }
        temp=temp->link;
    }
    return DATA_NOT_FOUND;
}