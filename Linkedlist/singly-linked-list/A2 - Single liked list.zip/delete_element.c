#include "sll.h"

int sl_delete_element(Slist **head, data_t data)
{
    Slist *temp = *head;
    Slist *prev = NULL;

    // list empty
    if (*head == NULL)
    {
        return LIST_EMPTY;
    }

    while (temp != NULL)
    {
        if (temp->data == data)
        {
            if (prev == NULL)
            {
                *head = temp->link;
            }
            else
            {
                prev->link = temp->link;
            }

            free(temp);
            return SUCCESS;
        }

        prev = temp;
        temp = temp->link;
    }

    return DATA_NOT_FOUND;
}
