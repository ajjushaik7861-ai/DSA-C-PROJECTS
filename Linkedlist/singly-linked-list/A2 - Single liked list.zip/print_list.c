#include "sll.h"

void print_list(Slist *head)
{
	if (head == NULL)
	{
		return;
	}
    else
    {
	    while (head)		
	    {
		    printf("%d -> ", head -> data);
		    head = head -> link;
	    }

	    printf("NULL\n");
    }
}