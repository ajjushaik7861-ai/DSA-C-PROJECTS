#include "sll.h"
/* Function to get the middle of the linked list*/
int find_mid(Slist *head, int *mid) 
{ 
    Slist *fast=head;
    Slist *slow=head;
    
    if(head==NULL)
    {
        return LIST_EMPTY;
    }
    
    while(fast!=NULL && fast->link!=NULL)
    {
        fast=fast->link->link;
        slow=slow->link;
    }
    *mid=slow->data;
} 