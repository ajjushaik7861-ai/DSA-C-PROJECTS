#include "sll.h"
/* Function to get the nth node from the last of a linked list*/
int find_nth_last(Slist *head, int pos, int *data) 
{ 
    Slist *fast=head;
    Slist *slow=head;
    
    if(fast==NULL)
    {
        return LIST_EMPTY;
    }
    if(pos<=0)
    {
        return FAILURE;
    }
    
    int count=1;
    while(fast!=NULL)
    {
        if(count<=pos)
        {
            fast=fast->link;
            count++;
        }
        else
        {
            fast=fast->link;
            slow=slow->link;
        }
    }
    
    if(count<=pos)
    {
        return FAILURE;
    }
    *data=slow->data;
    return SUCCESS;
} 