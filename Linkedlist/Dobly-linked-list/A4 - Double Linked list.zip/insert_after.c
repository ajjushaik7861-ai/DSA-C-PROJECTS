#include "dll.h"

int dl_insert_after(Dlist **head, Dlist **tail, int gdata, int ndata)
{
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    Dlist *temp=*head;
    
    while(temp!=NULL)//search for gdata
    {
        if(temp->data==gdata)
        break;
        temp=temp->next;
    }
    if(temp==NULL)
    {
        return DATA_NOT_FOUND;
    }
    
    Dlist *new=malloc(sizeof(Dlist));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=ndata;
    
    if(temp==*tail)
    {
        new->next=NULL;
        new->prev=*tail;
        (*tail)->next=new;
        *tail=new;
    }
    else
    {
        new->next=temp->next;
        new->prev=temp;
        temp->next->prev=new;
        temp->next=new;
    }
    return SUCCESS;
}