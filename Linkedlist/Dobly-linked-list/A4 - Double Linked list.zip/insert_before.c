#include "dll.h"

int dl_insert_before(Dlist **head, Dlist **tail, int gdata, int ndata)
{
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    Dlist *temp=*head;
    
    while(temp!=NULL)///search for data
    {
        if(temp->data==gdata)
        break;
        temp=temp->next;
    }
    if(temp==NULL)
    {
        return DATA_NOT_FOUND;
    }
    
    Dlist *new=malloc(sizeof(Dlist));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=ndata;
    
    if(temp==*head)//inserting before the first node
    {
        new->prev=NULL;
        new->next=*head;
        (*head)->prev=new;
        *head=new;
    }
    else
    {
        new->prev=temp->prev;
        new->next=temp;
        temp->prev->next=new;
        temp->prev=new;
    }
    return SUCCESS;
}