#include "dll.h"

int dl_delete_element(Dlist **head, Dlist **tail, int data)
{	
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    
    Dlist *temp=*head;
    while(temp!=NULL)
    {
        if(temp->data==data)
        break;
        temp=temp->next;
    }
    if(temp==*head)//DELETE first node 
    {
        *head=temp->next;
        (*head)->prev=NULL;
        free(temp);
        return SUCCESS;
    }
    if(temp==*tail)
    {
        *tail=temp->prev;
        (*tail)->next=NULL;
        free(temp);
        return SUCCESS;
    }
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;
    free(temp);
    return SUCCESS;
}