#include "dll.h"

int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
    //create new node
    Dlist *new=malloc(sizeof(Dlist));
    if(new==NULL)
    {
        return FAILURE;
    }
    //update the data and link
    new->data=data;
    new->prev=NULL;
    new->next=NULL;
    
    //check list is empty or not 
    if(*head==NULL)
    {
        *head=new;
        *tail=new;
    }
    else
    {
        new->next=*head;
        (*head)->prev=new;
        *head=new;
    }
    return SUCCESS;
}
