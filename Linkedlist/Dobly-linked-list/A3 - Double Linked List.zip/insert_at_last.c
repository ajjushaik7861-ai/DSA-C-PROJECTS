#include "dll.h"

int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
    //create new node
    Dlist *new=malloc(sizeof(Dlist));
    if(new==NULL)
    {
        return FAILURE;
    }
    //update the data and link
    new->data=data;
    new->prev=NULL;
    new->next=NULL;
    
    //check list is empty or not 
    if(*tail==NULL)
    {
        *head=new;
        *tail=new;
    }
    else
    {
        new->prev=*tail;
        (*tail)->next=new;
        *tail=new;
    }
    return SUCCESS;
}