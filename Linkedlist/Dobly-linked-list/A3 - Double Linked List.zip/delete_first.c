#include "dll.h"

int dl_delete_first(Dlist **head, Dlist **tail)
{
    if(*head==NULL)//list is empty
    {
        return FAILURE;
    }
    
    Dlist *temp=*head;
    
    if(*head==*tail)//if one node in list
    {
        *head=NULL;
        *tail=NULL;
    }
    else
    {
        *head=temp->next;
        (*head)->prev=NULL;
    }
    
    free(temp);
    return SUCCESS;
}