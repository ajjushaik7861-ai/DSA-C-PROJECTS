#include "dll.h"

int dl_delete_list(Dlist **head, Dlist **tail)
{
    if(*head==NULL)//list is empty
    {
        return FAILURE;
    }
    Dlist *temp=*head;
    Dlist *next;
    
    while(temp!=NULL)
    {
        next=temp->next;
        free(temp);
        temp=next;
    }
    //after deleting all nodes update head and tail
    *head=NULL;
    *tail=NULL;
    return SUCCESS;
}