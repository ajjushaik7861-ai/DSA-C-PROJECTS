#include "dll.h"

int dl_delete_last(Dlist **head, Dlist **tail)
{
    if(*tail==NULL)
    {
        return FAILURE;
    }
    
    Dlist *temp=*tail;
    
    //if only one node;
    if(*head==*tail)
    {
        *head=NULL;
        *tail=NULL;
    }
    else
    {
        *tail=temp->prev;
        (*tail)->next=NULL;
    }
    free(temp);
    return SUCCESS;
}